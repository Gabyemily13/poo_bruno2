package br.com.classes;

public class veiculo {
	
	//atributos
	
	public String nome;
	public String cor;
	public String rodas;
	public String motor;
	public float velocidade;

	//ações
	
	public void ligar() {
		
		System.out.println("O veículo ligou!");
	}
	
	public void desligar() {
		
		System.out.println("O veículo desligou!");
		
	}
	
}
