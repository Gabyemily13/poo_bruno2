package br.com.sesi;

public class Ola_mundo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Olá Mundo!");

	}

}
